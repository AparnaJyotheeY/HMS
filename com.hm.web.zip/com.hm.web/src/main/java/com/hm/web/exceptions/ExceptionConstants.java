package com.hm.web.exceptions;

public class ExceptionConstants {
	public static final String INVALID_USER_LOGIN = "Invalid User Credentials";
	public static final String INVALID_USER_LOGIN_CODE = "IUL001";
}

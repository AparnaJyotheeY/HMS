package com.hm.web.util;

public class ApplicationConstants {

	public static final String USER_DEFAULT_PASSWORD = "password";
	public static final long MAX_FILE_SIZE = 600000000;
	public static final String LOGIN_BEAN = "LOGIN_BEAN";
}